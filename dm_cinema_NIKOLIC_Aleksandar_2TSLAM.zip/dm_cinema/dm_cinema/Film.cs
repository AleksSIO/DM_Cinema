﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dm_cinema
{
    public class Film
    {
        private readonly int annee;
        private readonly string genre;
        private readonly int idFilm;
        private readonly string resume;
        private readonly string titre;
        private Acteur acteurPrincipal;

        private Film(int idFilm, string titre, int annee, string genre, string resume)
        {
            this.annee = annee;
            this.genre = genre;
            this.idFilm = idFilm;
            this.resume = resume;
            this.titre = titre;
            acteurPrincipal = Acteur.GetInstance(0, "aaaa", "bbbb", "00/00/00");
        }

        public static Film GetInstance(int idFilm, string titre, int annee, string genre, string resume)
        {
            Film film = new(idFilm, titre, annee, genre, resume);
            return film;
        }

        public string GetGenre() 
        {
            return genre;
        }

        public int GetIdFilm() 
        {
            return idFilm;
        }

        public int GetAnnee()
        {
            return annee;
        }

        public string GetTitre()
        {
            return titre;
        }

        public string GetResume()
        {
            return resume;
        }

        public Acteur GetActeurPrincipal()
        {
            return acteurPrincipal;
        }

        public void SetActeurPrincipal(Acteur acteur)
        {
            acteurPrincipal = acteur;
        }

        public override string ToString()
        {
            return $"Titre : {this.titre}\nAnnée : {this.annee}\nGenre : {this.genre}\nRésumé : {this.resume}\nActeur principal: {acteurPrincipal.GetPrenom()} {acteurPrincipal.GetNom()}";
        }
    }
}