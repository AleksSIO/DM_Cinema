﻿// See https://aka.ms/new-console-template for more information
using dm_cinema;

/* Test 1
Film monFilm = Film.GetInstance(1, "Blade Runner", 1982, "Science-Fiction", "L'action du film se situe à Los Angeles en 2019 "
    + "et met en scène Rick Deckard (interprété par Harrison Ford), un ancien policier qui reprend du service pour traquer un groupe "
    + "de réplicants, des androïdes créés à l'image de l'Homme, menés par l'énigmatique Roy Batty (interprété par Rutger Hauer).");

Console.WriteLine(monFilm.ToString());

*/

/* Test 2

Acteur monActeur = Acteur.GetInstance(1, "Ford", "Harisson", "13/06/1942");

Console.WriteLine(monActeur.ToString());

*/

Cinema monCinema = Cinema.GetInstance();
monCinema.SetActeur(1, "Ford", "Harisson", "13/06/1942");
monCinema.SetActeur(2, "Hanks", "Tom", "09/07/1956");
monCinema.SetFilm(1, "Blade Runner", 1982, "Science-Fiction", "L'action du film se situe à Los Angeles en 2019 "
    + "et met en scène Rick Deckard (interprété par Harrison Ford), un ancien policier qui reprend du service pour traquer un groupe "
    + "de réplicants, des androïdes créés à l'image de l'Homme, menés par l'énigmatique Roy Batty (interprété par Rutger Hauer).");
monCinema.SetFilm(2, "Toy Story", 1992, "Animation", "Le film met en scène un groupe de jouets. Woody, une poupée représentant un cow-boy, "
    + "et Buzz l'Éclair, une figurine d'astronaute, en sont les personnages principaux.");

Film bladeRunner = monCinema.GetFilm(1);
bladeRunner.SetActeurPrincipal(monCinema.GetActeur(1));
Film toyStory = monCinema.GetFilm(2);
toyStory.SetActeurPrincipal(monCinema.GetActeur(2));

Console.WriteLine(bladeRunner.ToString());
Console.WriteLine("\n");
Console.WriteLine(toyStory.ToString()); 

