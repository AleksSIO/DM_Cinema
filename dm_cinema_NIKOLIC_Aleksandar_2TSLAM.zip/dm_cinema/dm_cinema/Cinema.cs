﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace dm_cinema
{
    public class Cinema
    {
        #pragma warning disable IDE0051 // Supprimer les membres privés non utilisés
        private readonly Cinema cine;
        #pragma warning restore IDE0051 // Supprimer les membres privés non utilisés
        private readonly List<Acteur> lesActeurs;
        private readonly List<Film> lesFilms;

        #pragma warning disable CS8618 // Un champ non-nullable doit contenir une valeur non-null lors de la fermeture du constructeur. Envisagez de déclarer le champ comme nullable.
        private Cinema()
        #pragma warning restore CS8618 // Un champ non-nullable doit contenir une valeur non-null lors de la fermeture du constructeur. Envisagez de déclarer le champ comme nullable.
        {
            this.lesActeurs = new List<Acteur>();
            this.lesFilms = new List<Film>();
        }

        public static Cinema GetInstance()
        {
            Cinema cinema = new();
            return cinema;
        }

        public Acteur GetActeur(int id)
        {
            Acteur acteur = Acteur.GetInstance(0, "aaaa", "bbbb", "00/00/00");
            foreach(Acteur a in lesActeurs)
            {
                if(a.GetId() == id)
                {
                    acteur = a;
                }
            }
            return acteur;
        }

        public Film GetFilm(int id)
        {
            Film film = Film.GetInstance(0, "aaaa", 0000, "bbbb", "cccc");
            foreach(Film f in lesFilms)
            {
                if(f.GetIdFilm() == id)
                {
                    film = f;
                }
            }
            return film;
        }

        public int NbActeur()
        {  
            return lesActeurs.Count;
        }

        public int NbFilms()
        {
            return lesFilms.Count;
        }

        public void SetFilm(int idFilm, string titre, int annee, string genre, string resume)
        {
            Film film = Film.GetInstance(idFilm, titre, annee, genre, resume);
            lesFilms.Add(film);
        }

        public void SetActeur(int idActeur, string nom, string prenom, string anneeNaissance)
        {
            Acteur acteur = Acteur.GetInstance(idActeur, nom, prenom, anneeNaissance);
            lesActeurs.Add(acteur);
        }
    }
}
