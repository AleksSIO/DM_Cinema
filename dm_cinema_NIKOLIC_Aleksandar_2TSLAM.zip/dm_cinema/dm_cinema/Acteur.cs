﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dm_cinema
{
    public class Acteur
    {
        private readonly string anneeNaissance;
        private readonly int id;
        private readonly string nom;
        private readonly string prenom;

        private Acteur(int id, string nom, string prenom, string anneeNaissance)
        {
            this.id = id;
            this.nom = nom;
            this.prenom = prenom;
            this.anneeNaissance = anneeNaissance;
        }

        public static Acteur GetInstance(int id, string nom, string prenom, string anneeNaissance)
        {
            Acteur acteur = new(id, nom, prenom, anneeNaissance);
            return acteur;
        }

        public int GetId() 
        {
            return id;
        }

        public string GetNom() 
        {
            return nom;
        }

        public string GetPrenom()
        {
            return prenom;
        }

        public string GetAnneeNaissance()
        {
            return anneeNaissance;
        }

        public override string ToString()
        {
            return $"nom : {this.nom}  prénom : {this.prenom}  année de naissance : {this.anneeNaissance}";
        }
    }
}
